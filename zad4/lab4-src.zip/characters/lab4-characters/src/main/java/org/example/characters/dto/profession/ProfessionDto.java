package org.example.characters.dto.profession;

import lombok.Value;

@Value
public class ProfessionDto {
     private String name;
     private int unlockLevel;
}
